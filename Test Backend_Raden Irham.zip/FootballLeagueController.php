<?php

namespace App\Http\Controllers;

use App\Models\Footballleague;
use Facade\FlareClient\Http\Response;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Symfony\Component\HttpFoundation\Response as HttpFoundationResponse;

class BukuController extends Controller
{
    public function index()
    {
        $buku = Football::orderBy('created_at', 'DESC')->paginate(5);
        $response = [
            'message' => 'Data Club',
            'data' => $Footballleague,
        ];
        return response()->json($response, HttpFoundationResponse::HTTP_OK);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
           "id_club" => ['required'],
           "clubhomename" => ['required'],
            "clubawayname" => ['required'],
            "score" => ['required'],
        ]);

        if ($validator->fails()) {
            return response()->json(
                $validator->errors(),
                HttpFoundationResponse::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        try {
            $buku = Buku::create($request->all());

            $response = [
                'message' => 'Berhasil disimpan',
                'data' => $football,
            ];

            return response()->json($response, HttpFoundationResponse::HTTP_CREATED);
        } catch (QueryException $e) {
            return response()->json([
                'message' => "Gagal " . $e->errorInfo,
            ]);
        }
    }

    public function show($id_club)
    {
        $football = Football::where('id_club', $id_club)->firstOrFail();
        if (is_null($Football)) {
            return $this->sendError('Club tidak diemukan');
        }
        return response()->json([
            "success" => true,
            "message" => "Data Club ditemukan.",
            "data" => $football,
        ]);
    }

    public function update(Request $request, $id_club)
    {
        $football = football::find($id_club);
        $football->update($request->all());
        return response()->json([
            "success" => true,
            "message" => "Data club telah diubah.",
            "data" => $footbal,
        ]);
    }

    public function destroy($id_club)
    {
        $deletedRows = Football::where('id_club', $id_club)->delete();
        return response()->json([
            "success" => true,
            "message" => "Data club berhasil dihapus.",
            "data" => $deletedRows,
        ]);
    }
}