<?php
use App\Http\Controllers\FootballLeagueController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/FootballLeague', [FootballLeagueController::class, 'index']);
Route::post('/FootballLeague', [FootballLeague::class, 'store']);