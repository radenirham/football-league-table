Ladda.bind('button[type=submit]');
